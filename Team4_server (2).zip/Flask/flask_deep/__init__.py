import os

real_path = os.path.dirname(os.path.realpath(__file__))
sub_path = os.path.split(real_path)[0]
os.chdir(sub_path)

from flask import Flask, request
from flask.templating import render_template
from . import OCR_converter
from . import Make_answer
from . import tacotron2_wavenet_korean_tts
from . import TextRank_Processor 
import importlib

app = Flask(__name__)
app.debug = True


def root_path():
    '''root 경로 유지'''
    real_path = os.path.dirname(os.path.realpath(__file__))
    sub_path = "\\".join(real_path.split("\\")[:-1])
    return os.chdir(sub_path)


''' Main page '''


@app.route('/')
def index():
    return render_template('OCR_get.html')


''' OCR '''


@app.route('/OCR_get')
def OCR_get():
    return render_template('OCR_get.html')


@app.route('/OCR_post', methods=['GET', 'POST'])
def OCR_post():
    importlib.reload(OCR_converter)
    if request.method == 'POST':
        root_path()

        # User Image (target image)
        user_img = request.files['user_img']
        user_img.save('./flask_deep/static/images/' + str(user_img.filename))
        user_img_path = '/images/' + str(user_img.filename)

        # OCR
        transfer_txt = OCR_converter.main(user_img_path)

    return render_template('OCR_post.html', user_img=user_img_path, transfer_txt=transfer_txt)

@app.route('/Make_answer_post', methods=['GET', 'POST'])
def Make_answer_post():
    importlib.reload(Make_answer)
    if request.method == 'POST':
        root_path()
        
        # context
        context_file_path = 'flask_deep/static/txt/context.txt'
        with open(context_file_path, 'r', encoding='UTF-8') as lf:
            strings = lf.readlines()
        context = "".join(strings)
        
        # problem
        problem_file_path = 'flask_deep/static/txt/problem.txt'
        problem = request.form['problem']
        with open(problem_file_path, 'w', encoding='UTF-8') as lf:
            lf.writelines("".join(problem))

        # make answer
        args=[context_file_path, problem_file_path]
        answer = Make_answer.main(args)

    return render_template('Make_answer_post.html', context=context, problem=str(problem), answer=answer)


@app.route('/tacotron_post', methods=['GET', 'POST'])
def tacotron_post():
    importlib.reload(tacotron2_wavenet_korean_tts)
    importlib.reload(TextRank_Processor)
    if request.method == 'POST':
        root_path()
        
        # context
        context_file_path = 'flask_deep/static/txt/context.txt'
        with open(context_file_path, 'r', encoding='UTF-8') as lf:
            strings = lf.readlines()
        
        text = "".join(strings)
        context = TextRank_Processor.main(text)
        
        # problem
        problem_file_path = 'flask_deep/static/txt/problem.txt'
        with open(problem_file_path, 'r', encoding='UTF-8') as lf:
            strings = lf.readlines()
        problem = "".join(strings)
        
        answer_file_path = 'flask_deep/static/txt/answer.txt'
        with open(answer_file_path, 'r', encoding='UTF-8') as lf:
            strings = lf.readlines()
        answer = "".join(strings)
        
        answer_voice_path = 'flask_deep/static/sounds/'
        args = [answer_file_path, answer_voice_path]
        tacotron2_wavenet_korean_tts.main(args)
        file_list = os.listdir(answer_voice_path)
        for file in file_list:
            if ".wav" in file:
                answer_voice = file
        
        voice_path = 'sounds/' + str(answer_voice)
        
        
    return render_template('tacotron_post.html', answer_voice=voice_path, context=context, problem=problem, answer=answer)