import json
import random
import shutil
import os
import pandas as pd
import pickle

from pathlib import Path
import torch
import numpy as np
from tqdm.notebook import tqdm
from torch.utils.data import Dataset, DataLoader
from transformers import AutoTokenizer, AutoModelForQuestionAnswering, AdamW


print(os.getcwd())

def add_end_idx(answers, contexts):
    for answer, context in zip(answers, contexts):
        gold_text = answer['text']
        start_idx = answer['answer_start']
        end_idx = start_idx + len(gold_text)

        if context[start_idx:end_idx] == gold_text:
            answer['answer_end'] = end_idx
        elif context[start_idx-1:end_idx-1] == gold_text:
            answer['answer_start'] = start_idx - 1
            answer['answer_end'] = end_idx - 1
        elif context[start_idx-2:end_idx-2] == gold_text:
            answer['answer_start'] = start_idx - 2
            answer['answer_end'] = end_idx - 2
            
def prediction(contexts, questions):
    device = torch.device('cuda') if torch.cuda.is_available() else torch.device('cpu')
    
    tokenizer = AutoTokenizer.from_pretrained("klue/bert-base")
    model = AutoModelForQuestionAnswering.from_pretrained("flask_deep/static/models")
    
    model.to(device)
    model.eval()
    
    result = []
    
    with torch.no_grad():
        for context, question in zip(contexts, questions):
            encodings = tokenizer(context, question, max_length=512, truncation=True,
                                     padding="max_length", return_token_type_ids=False)
            encodings = {key: torch.tensor([val]) for key, val in encodings.items()}
            
            input_ids = encodings["input_ids"].to(device)
            attention_mask = encodings["attention_mask"].to(device)
            
            outputs = model(input_ids, attention_mask=attention_mask)
            start_logits, end_logits = outputs.start_logits, outputs.end_logits
            token_start_index, token_end_index = start_logits.argmax(dim=-1), end_logits.argmax(dim=-1)
            pred_ids = input_ids[0][token_start_index: token_end_index + 1]
            pred = tokenizer.decode(pred_ids)
            result.append(pred)

    return result


def main(args):
    
    context_file_path = args[0]
    with open(context_file_path, 'r', encoding='UTF-8') as lf:
        strings = lf.readlines()
    
    context = strings
    
    problem_file_path = args[1]
    with open(problem_file_path, 'r', encoding='UTF-8') as lf:
        strings = lf.readlines()
        
    problem = strings
    
    custom_pred = prediction(context, problem)
    pred_file_path = "flask_deep/static/txt/answer.txt"
    with open(pred_file_path, 'w', encoding='UTF-8') as lf:
        lf.writelines("".join(custom_pred))
    
    return custom_pred


if __name__ == "__main__":
    main()
