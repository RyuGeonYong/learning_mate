# -*- coding: utf-8 -*-

from .datafeeder_wavenet import DataFeederWavenet