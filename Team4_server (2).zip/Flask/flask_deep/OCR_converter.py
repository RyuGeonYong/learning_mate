import easyocr
import cv2
import os
from hanspell import spell_checker
import re


def text_length_limit(target, length=500):
    target_limit = []

    for idx in range(len(target)):
        if len(target[idx]) < length:
            target_limit.append(target[idx])

        else:
            target_limit.append("$$" + target[idx][0:length])
            target_limit.append(target[idx][length:len(target[idx])])
    
    return target_limit

def image_get(image_path):
    img = cv2.imread(image_path)
    return img


print(os.getcwd())


def main(target_img_path):
    # image 파일명
    target_img_path = target_img_path.split('/')[-1]
    # image 경로
    target_image_path = 'flask_deep/static/images/' + target_img_path  # 타깃 이미지

    img = image_get(target_image_path)

    reader = easyocr.Reader(['ko', 'en'], gpu=True, download_enabled=True)
    result = reader.readtext(img, detail=0)
    
    split_text = text_length_limit("".join(result))
    
    result = spell_checker.check(split_text)
    
    combined_text = []
    for text in result:
        combined_text.append(text.checked)
        
    output_file_path = "flask_deep/static/txt/context.txt"
    with open(output_file_path, 'w', encoding='UTF-8') as lf:
        lf.writelines("".join(combined_text))
    
    return "".join(combined_text)


if __name__ == "__main__":
    main()
